module.exports = {
  path: '/api/auth/load',
  method: 'GET',
  template: {
    username: 'joe'
  }
}

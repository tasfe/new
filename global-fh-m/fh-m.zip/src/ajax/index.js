import ajax from './ajax'
module.exports = ajax

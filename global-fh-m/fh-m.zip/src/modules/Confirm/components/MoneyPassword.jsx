import React, { Component, PropTypes } from 'react'
import WithStyles from 'with-style'
import styles from './MoneyPassword.css'

@WithStyles(styles)
class MoneyPassword extends Component {
  constructor () {
    super()
  }

  render () {
    return <div>i am moenyPassword</div>
  }
}

export default MoneyPassword

module.exports = {
  path: '/api/user/login',
  method: 'GET',
  template: {
    username: 'joe',
    password: 'joe'
  }
}
